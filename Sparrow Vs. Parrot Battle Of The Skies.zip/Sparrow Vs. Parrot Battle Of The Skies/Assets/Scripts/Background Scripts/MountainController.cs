﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MountainController : MonoBehaviour {

	//Make Unity Serialize private variables
	[SerializeField]
	private float speed = 5f;
	[SerializeField]
	private float startHorizontal;
	[SerializeField]
	private float endHorizontal;

	//private variables that are not Serialized
	private Transform _transform;
	private Vector2 _currentPosition;


	// Use this for initialization
	void Start () {
		//Getting the gameobject component transform.
		_transform = gameObject.GetComponent<Transform> ();

		////Making the current position the transform position.
		_currentPosition = _transform.position;

		//Reset
		Reset();
	}


	// Update is called once per frame
	void Update () {
		//Making the current position the transform position.
		_currentPosition = transform.position;

		//Move City horizontally
		_currentPosition -= new Vector2(speed, 0);

		//Check if you need to reset
		if (_currentPosition.x < endHorizontal) {
			//reset
			Reset();
		}

		//Apply changes to the current position of city background)
		_transform.position = _currentPosition;

	}

	private void Reset() {
		_currentPosition = new Vector2 (startHorizontal, 0);
	}
}
