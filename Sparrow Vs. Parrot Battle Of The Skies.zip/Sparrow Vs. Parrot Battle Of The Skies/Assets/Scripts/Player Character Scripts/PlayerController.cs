﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

		[SerializeField]
		private float speed = 7f;
		[SerializeField]
		private float moveLeftX;
		[SerializeField]
		private float moveRightX;
		[SerializeField]
		private float moveUpY;
		[SerializeField]
		private float moveDownY;


	private Transform _transform;

	private Vector2 _currentPosition;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform>();
		_currentPosition = _transform.position;
	}
		// Update is called once per frame
		void Update () {
		_currentPosition = transform.position;
			if(Input.GetKey(KeyCode.A)){
			_currentPosition -= new Vector2 (speed, 0);
				transform.localScale = new Vector2(-0.07032935f, 0.07771432f);
			}
			if(Input.GetKey(KeyCode.D)){
			_currentPosition += new Vector2(speed, 0);
			transform.localScale = new Vector2(0.07032935f, 0.07771432f);
			}
			if(Input.GetKey(KeyCode.S)){
			_currentPosition -= new Vector2(0, speed);
			}
			if(Input.GetKey(KeyCode.W)){
			_currentPosition += new Vector2(0, speed);
			}
			Boundary();
		_transform.position = _currentPosition;
		}
		private void Boundary(){
		
		if (_currentPosition.x < moveLeftX) {
			_currentPosition.x = moveLeftX;
		}
			if (_currentPosition.x > moveRightX) {
				_currentPosition.x = moveRightX;
			}
			if (_currentPosition.y > moveUpY) {
				_currentPosition.y = moveUpY;
			}
			if (_currentPosition.y < moveDownY) {
				_currentPosition.y = moveDownY;
			}
				
		}
	
	}