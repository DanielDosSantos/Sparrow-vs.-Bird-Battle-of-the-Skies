﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdSeedCollision : MonoBehaviour {

	public AudioSource _dingSound;


	public void OnTriggerEnter2D(Collider2D collider){
		if (collider.gameObject.tag.Equals ("Player")) {
			Debug.Log ("Player");
			_dingSound.Play ();
		} else if (collider.gameObject.tag.Equals ("Enemy")) {
			Debug.Log ("Enemy");
			collider.gameObject.GetComponent<EnemiesController> ().Reset ();

		}
	}

	// Use this for initialization
	void Start () {
		_dingSound = GetComponent<AudioSource> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
