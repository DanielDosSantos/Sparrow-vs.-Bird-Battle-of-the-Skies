﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCollision : MonoBehaviour {

	public AudioSource _hitSound;


	public void OnTriggerEnter2D(Collider2D collider){
		if (collider.gameObject.tag.Equals ("Seed")) {
			Debug.Log ("Bonus");
			collider.gameObject.GetComponent<BirdSeedController> ().Reset ();
		} 

			else if (collider.gameObject.tag.Equals ("Player")) {
			Debug.Log ("Player");
			_hitSound.Play ();


		}
	}

	// Use this for initialization
	void Start () {
		_hitSound = GetComponent<AudioSource> ();
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
