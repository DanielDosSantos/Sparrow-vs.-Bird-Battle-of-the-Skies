﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemiesController : MonoBehaviour {
	[SerializeField]
	private float speed = 5f;

	[SerializeField]
	private float startPointY;

	[SerializeField]
	private float endPointY;

	[SerializeField]
	private float startPointX; 

	[SerializeField]
	private float endPointX;

	private Transform _transform = null;
	private Vector2 _currentPosition;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPosition = _transform.position;
		Reset ();
	}

	// Update is called once per frame
	void Update () {
		_currentPosition= _transform.position;

		//Changing the Y value according to given speed from left to right.
		_currentPosition -= new Vector2 (speed, 0); 


		if (_currentPosition.y < endPointY) {
			Reset ();
		}

		_transform.position = _currentPosition;

	}
		

	public void Reset() {
		float x = Random.Range (startPointX, endPointX);
		float dy = Random.Range (0, 100);
		_transform.position = new Vector2 (x, startPointY+dy);
	}
}
