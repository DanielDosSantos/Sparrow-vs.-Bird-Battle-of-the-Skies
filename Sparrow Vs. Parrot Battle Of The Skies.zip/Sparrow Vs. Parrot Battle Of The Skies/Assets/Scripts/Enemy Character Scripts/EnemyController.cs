﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

	[SerializeField]
	float minimumYSpeed = 5f;
	[SerializeField]
	float maximumYSpeed = 10f;
	[SerializeField]
	float minimumXSpeed = -2f;
	[SerializeField]
	float maximumXSpeed = 2f;

	private Transform _transform;
	private Vector2 _currentSpeed;
	private Vector2 _currentPosition;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		Reset ();
	}

	public void Reset(){

		float xSpeed = Random.Range (minimumXSpeed, maximumXSpeed);
		float ySpeed = Random.Range (minimumYSpeed, maximumYSpeed);

		_currentSpeed = new Vector2 (xSpeed, ySpeed);

		float x = Random.Range (88, -87); 
		_transform.position = new Vector2 (120 + Random.Range (0, 50), x);

	}

	// Update is called once per frame
	void Update () {
		_currentPosition = _transform.position;
		_currentPosition -= _currentSpeed;
		_transform.position = _currentPosition;

		if (_currentPosition.x <= -450) {
			Reset ();
		}
	}
}
